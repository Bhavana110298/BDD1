package Booking;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"pretty"}, features="C:\\Users\\vebhavan\\Documents\\BDD\\BDDCaseStudyFinal\\src\\test\\resources\\Booking\\Booking.feature", glue="Booking", dryRun=false) 
public class TestRunner {

}